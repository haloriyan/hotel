<?php
include '../ctrl/booking.php';

$id = $_POST['id'];
$booking->tolak($id);
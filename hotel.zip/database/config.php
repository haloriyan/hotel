<?php
global $dbHost,$dbUsername,$dbPassword,$dbName;

$dbHost 	= "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName 	= "hotel";

// $dbHost 	= "spectre.beon.co.id";
// $dbUsername = "imajingg_test";
// $dbPassword = "inikatasandi2908;";
// $dbName 	= "imajingg_testDb";

?>
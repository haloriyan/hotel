<?php
global $dbHost,$dbUsername,$dbPassword,$dbName;

$dbHost 	= "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName 	= "hotel";

?>